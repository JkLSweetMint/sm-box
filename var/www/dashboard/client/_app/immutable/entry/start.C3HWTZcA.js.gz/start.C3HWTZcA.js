import{a as t}from"../chunks/entry.DvJ_tHr6.js";export{t as start};
