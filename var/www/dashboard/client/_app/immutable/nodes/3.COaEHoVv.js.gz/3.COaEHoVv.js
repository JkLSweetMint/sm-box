import{s}from"../chunks/scheduler.VUuLSjLj.js";import{S as t,i as e}from"../chunks/index.YcojCQiS.js";class l extends t{constructor(o){super(),e(this,o,null,null,s,{})}}export{l as component};
