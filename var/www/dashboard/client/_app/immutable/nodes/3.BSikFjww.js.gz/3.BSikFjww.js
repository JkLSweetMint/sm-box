import{s}from"../chunks/scheduler.C73wj8LU.js";import{S as t,i as e}from"../chunks/index.DcrltIXL.js";class l extends t{constructor(o){super(),e(this,o,null,null,s,{})}}export{l as component};
