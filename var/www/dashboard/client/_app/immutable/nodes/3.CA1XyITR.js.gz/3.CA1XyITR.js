import{s}from"../chunks/scheduler.B5rZiKyw.js";import{S as t,i as e}from"../chunks/index.DrETqFkR.js";class l extends t{constructor(o){super(),e(this,o,null,null,s,{})}}export{l as component};
