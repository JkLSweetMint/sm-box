import{s}from"../chunks/scheduler.B4NQwY3t.js";import{S as t,i as e}from"../chunks/index.gMR2UOS6.js";class l extends t{constructor(o){super(),e(this,o,null,null,s,{})}}export{l as component};
