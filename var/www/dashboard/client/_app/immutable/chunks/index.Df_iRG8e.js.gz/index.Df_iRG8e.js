const c=function(t){const n=String(t).trim();return n&&n!=""?` ${n}`:""};export{c};
